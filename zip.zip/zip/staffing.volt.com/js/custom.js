if (typeof (Ektron.Controls) == 'undefined') {
        Ektron.Controls = {};
    }
 
    Ektron.Controls.SmartFlexMenu = {
        /* properties */
        isSelected: false,
        expandTreeLoop: 0,
        /* methods */
 
        initMenu: function () {
            // Default behaviour
            Ektron.Controls.SmartFlexMenu.Default();
 
            // Expand all Submenus which has css class 'expand' (Regards to folder Associations.)
            Ektron.Controls.SmartFlexMenu.ExpandMenu();
 
            // Expand all Submenus which has selected menu item. (Regards to URL.)
            Ektron.Controls.SmartFlexMenu.SelectMenuItem();
        },
 
        Default: function () {
            $("ul.subnav").parent().append("<span></span>"); //Only shows drop down trigger when js is enabled (Adds empty span tag after ul.subnav*)
            $("ul.subnav li").hover(function () { //When trigger is clicked...
 
                //Following events are applied to the subnav itself (moving subnav up and down)
                $(this).find("ul.subnav").slideDown('fast').show(); //Drop down the subnav on click
 
                $(this).hover(function () {
                }, function () {
                    $(this).find("ul.subnav").slideUp('fast'); //When the mouse hovers out of the subnav, move it back up
                });
 
                //Following events are applied to the trigger (Hover events for the trigger)
            }).hover(function () {
                $(this).addClass("subhover"); //On hover over, add class "subhover"
            }, function () {    //On Hover Out
                $(this).removeClass("subhover"); //On hover out, remove class "subhover"
            });
        },
 
        ExpandMenu: function () {
            $('.expand').parents('.subnav').show();
            $('.expand').next().show();
        },
 
        SelectMenuItem: function () {
            var selecteditem = $("a[itemselected='True']");
            $(selecteditem).addClass("active");
        }
    }
 
    Ektron.ready(function () {
        Ektron.Controls.SmartFlexMenu.initMenu();
    });